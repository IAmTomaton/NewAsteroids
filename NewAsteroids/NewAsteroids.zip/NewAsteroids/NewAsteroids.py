from Space import Space


def main():
    space = Space()
    space.start()


if __name__ == '__main__':
    main()
